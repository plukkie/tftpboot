#!/bin/bash
###########################################################################
ZTD_SERVER_IP="10.10.10.201"
SONIC_DEFAULT_NAME="sonic"
SONIC_DESIRED_NAME="SONiC-ZTP-Staged"
TFTP_SERVER_IP="10.10.10.201"
OOB_INT=eth0
ZTD_PATH=/tftpboot
CALLBACK=/callback
STAGING_FINISHED=/ztp_finished
INVENTORY=/ifabric_inventory
ADDON_SCRIPTS_PATH=/tftpboot/sonic/postscript_addons/
SAVE_CONFIG_FILE=save_config.sh
ENABLE_INTERFACES=enable_interfaces.sh
ADMIN_HOME=/home/admin/
CGI=/cgi-bin/callback.sh
APP=http://
CRONLINE=${ADMIN_HOME}${SAVE_CONFIG_FILE}
CRONROOT=/var/spool/cron/crontabs/root
USER_NAME=admin
PASSWORD=YourPaSsWoRd
PASSWORDLIST=( "${PASSWORD}" "admin" "admin123" "Password01" "Password01!" )
TMP=/tmp
ZTPFINISH="_ztp.finished"
###########################################################################

function change_password(){
  ## Set the password
  echo -e "admin123\nadmin123" | sudo passwd admin
}

## Extract the ip-address that was received from dhcp server
DHCP_IP=`hostname -I | awk '{printf $1}'`

CURRENTHOSTNAME=`hostname`

if [ "${CURRENTHOSTNAME}" = "${SONIC_DEFAULT_NAME}" ]
	then #switch has default ztp sonic name
		SWITCHNAME=${SONIC_DESIRED_NAME}
		echo "Current hostname is SONiC default: ${CURRENTHOSTNAME}"
		echo "Set new hostname permanent: ${SWITCHNAME}"
	else #switch has set different hostname via DHCP
		SWITCHNAME=${CURRENTHOSTNAME}
		echo "current hostname received: ${CURRENTHOSTNAME}"
		echo "Set new hostname permanent: ${SWITCHNAME}"
fi

# set hostname via localhost REST call
for ITEM in ${PASSWORDLIST[@]}; do
        curl -s -k -X PATCH "https://localhost/restconf/data/openconfig-system:system/config/hostname" -H "accept: */*" -H "Content-Type: application/yang-data+json" -u ${USER_NAME}:${ITEM} -d "{\"openconfig-system:hostname\":\"$SWITCHNAME\"}"
done

# get enable_interfaces addon script
#/usr/bin/curl --interface $OOB_INT -s ${APP}${ZTD_SERVER_IP}${ADDON_SCRIPTS_PATH}${ENABLE_INTERFACES} -o ${ADMIN_HOME}${ENABLE_INTERFACES}
#sleep 2
#chmod a+x ${ADMIN_HOME}${ENABLE_INTERFACES} && ${ADMIN_HOME}${ENABLE_INTERFACES}

sleep 2

# get save_config.sh addon script and add to crontab
/usr/bin/curl --interface $OOB_INT -s ${APP}${ZTD_SERVER_IP}${ADDON_SCRIPTS_PATH}${SAVE_CONFIG_FILE} -o ${ADMIN_HOME}${SAVE_CONFIG_FILE}
sleep 2
chmod a+x ${ADMIN_HOME}${SAVE_CONFIG_FILE}

# Check if save_config script present in crontab
if [[ ! -f "${CRONROOT}" ]]; then touch ${CRONROOT}; fi

if ! grep -q "${CRONLINE}" "${CRONROOT}"; then
   echo "* * * * * sudo $CRONLINE" >> ${CRONROOT}
fi

# Save config permanent
#config save -y

# Change admin pwd
echo "Change password for user admin..." && sleep 2
change_password

#Upload ZTP staging complete file to web server
ZTPFINISHFILE=`echo ${DHCP_IP}`${ZTPFINISH}
echo $SWITCHNAME > $ADMIN_HOME${ZTPFINISHFILE}
curl --interface $OOB_INT -T $ADMIN_HOME$ZTPFINISHFILE tftp://${TFTP_SERVER_IP}${STAGING_FINISHED}/${ZTPFINISHFILE}

#Upload inventory IP file to web server
#IPADDRESS=`echo ${DHCP_IP}`
#echo { \"hostname\" : \"$SWITCHNAME\" } > $ADMIN_HOME${IPADDRESS}
#curl --interface $OOB_INT -T $ADMIN_HOME$IPADDRESS tftp://${TFTP_SERVER_IP}${INVENTORY}/${IPADDRESS}

